<?php
$mainMenu = [
  '' => 'Home',
  'howitworks' => 'How it works',
  'testimonial' => 'Testimonial',
  'faq' => 'Faq',
  'guarantee' => 'Guarantee',
  'contact' => 'Contact',
  'aboutus' => 'About us',
  'order' => 'Order',
  //'blog' => 'Blog',
];
?>