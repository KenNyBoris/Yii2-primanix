<?php
use app\helpers\UtilityHelper;
$this->params['data'] = ['page' => 'home', 'title' => 'Home'];
?>
<div class="main-wrapper">
  <div class="wrapper-1">
    <img class="bg_wrapper1" src="./images/bg_wrapper1.png">
    <div class="container section-space position-relative">
      <img class="doctor_avatar" src="./images/actor_1.png">
      <div class="information_pane">
        <img class="verified" src="./images/verified.png">
        <p class="description text-center white pt-15">“Hi, I’m Dr. Fischer, and they call me the porn doctor. I’ve seen a lot of pills that claim to increase size, but only one supplement fits the bill. Superior Male has the extreme potency, quality, and results you need from a natural enlargement pill, and that’s why it’s the only supplement for adult porn stars!”</p>
        <img class="stars pt-15 pb-15" src="./images/stars.png">
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
  <div class="wrapper-2">
    <img class="bg_wrapper2" src="./images/bg_wrapper2.png">
    <div class="container">
      <div class="top_pane">
        <img class="actor2_avatar" src="./images/actor_2.png">
        <div class="offer_pane">
          <h2>IS <span class="lightgrey">SUPERIOR MALE</span> THE <br class="desktop-only"><span class="red">RIGHT</span> SUPPLEMENT<br class="desktop-only"> FOR YOU?</h2>
          <button class="uppercase">Answer these 4 questions</button>
        </div>
      </div>
    </div>
    <div class="item_section section-space bg-lightgrey">
      <img class="bg_effect" src="./images/bg_effect.png">
      <div class="container">
        <div class="question_pane">
          <div class="image_part">
            <img src="./images/item_1.png">
          </div>
          <div class="description_part">
            <p class="title">Question 1 of 4</p>
            <p class="description grey medium">Do you want to get bigger and <br class="desktop-only">harder erections?</p>
            <div class="btn_pane">
              <div class="btn_check">
                <img src="./images/btn_check.png">
                <h3 class="grey">YES</h3>
              </div>
              <div class="btn_check">
                <img src="./images/btn_fail.png">
                <h3 class="grey">NO</h3>
              </div>
            </div>
          </div>
        </div>
        <p class="description ml-30 mt-30 grey">The simple truth is that BIGGER is always BETTER when it comes to erection size. Countless research, tests, and surveys say that women have more satisfying orgasms when having sex with well-endowed men, and the #1 reason why women fail to orgasm is because of their partner’s erection size. Here’s the kicker – women only orgasm 10% of the time, and if your erection is on the small to average size, that means that you’re not satisfying your wife or girlfriend in bed.</p>
      </div>
    </div>
  </div>
  <div class="wrapper-3 bg-white">
    <div class="item_section section-space">
      <div class="container">
        <div class="question_pane">
          <div class="image_part">
            <img src="./images/item_2.png">
          </div>
          <div class="description_part">
            <p class="title">Question 2 of 4</p>
            <p class="description grey medium pb-15">If you can improve one aspect of <br class="desktop-only">your sexual skills, what would it be?</p>
            <div class="btn_pane">
              <div class="btn_check">
                <img src="./images/btn_check.png">
                <h3 class="grey">YES</h3>
              </div>
              <div class="btn_check">
                <img src="./images/btn_fail.png">
                <h3 class="grey">NO</h3>
              </div>
            </div>
          </div>
        </div>
        <ul class="ml-30 mt-30 grey">
          <li class="ml-30">Bigger and Harder Erections</li>
          <li class="ml-30">Long-lasting stamina during sex</li>
          <li class="ml-30">Massive loads when you orgasm</li>
          <li class="ml-30">A massive boost to your sex drive and energy</li>
        </ul>
        <p class="description ml-30 mt-30 grey">Superior Male’s Accelerated Expansion Formula is not all about boosting your erection hardness and size. The results you get with Superior Male go beyond the 1 to 4-inch boost in erect penis length and girth. Superior Male is also scientifically verified to double, or even TRIPLE your sexual desire, energy, and stamina like no other natural supplement has done before. On average, Superior Male users have sex about 10 times a week, lasting for at least 30 minutes before ejaculating, with at 2-3 different sexual partners! </p>
      </div>
    </div>
    <div class="item_section section-space bg-lightgrey">
      <div class="container">
        <div class="question_pane">
          <div class="image_part">
            <img src="./images/item_3.png">
          </div>
          <div class="description_part">
            <p class="title">Question 3 of 4</p>
            <p class="description grey medium pb-15">If given the opportunity, would you <br class="desktop-only">cheat on your long-term partner?</p>
            <div class="btn_pane">
              <div class="btn_check">
                <img src="./images/btn_check.png">
                <h3 class="grey">YES</h3>
              </div>
              <div class="btn_check">
                <img src="./images/btn_fail.png">
                <h3 class="grey">NO</h3>
              </div>
            </div>
          </div>
        </div>
        <p class="description ml-30 mt-30 grey">The REAL #1 cause of divorce in the United States is the lack of sexual satisfaction in their marriage. Many overlook the power of great sex in a relationship, and there are only a few marital problems that great sex can’t fix. A physical relationship is deeply rooted in procreation and sex, that’s why women prefer to stick with men who can satisfy their deepest carnal needs. This is also the reason why men with LARGE PENISES tend to be more confident than men with average-sized penises. Men unconsciously think that sex is a competition where the winner is the one who gets to give the most pleasure to women.</p>
      </div>
    </div>
    <div class="item_section section-space">
      <div class="container">
        <div class="question_pane">
          <div class="image_part">
            <img src="./images/item_4.png">
          </div>
          <div class="description_part">
            <p class="title">Question 4 of 4</p>
            <p class="description grey medium pb-15">Have you tried a natural enlargement <br class="desktop-only">supplement before?</p>
            <div class="btn_pane">
              <div class="btn_check">
                <img src="./images/btn_check.png">
                <h3 class="grey">YES</h3>
              </div>
              <div class="btn_check">
                <img src="./images/btn_fail.png">
                <h3 class="grey">NO</h3>
              </div>
            </div>
          </div>
        </div>
        <p class="description ml-30 mt-30 grey">Most Superior Male men have used another male enhancement supplement before, and it could be because of this chart why thousands of men are switching to Superior Male. Results start with the formulation, and NO SUPPLEMENT can match the power of Superior Male.</p>
        <p class="description ml-30 mt-30 grey">About 4 out of 10 men in the United States have tried sexual enhancement products, and about 97% of these men had unfortunate experiences with such products. Superior Male is a generation ahead of any other product in the market today. Just compare Superior Male with any other supplement and you’ll see why Superior Male outperforms other products on every level.</p>
      </div>
    </div>
  </div>
  <div class="wrapper-4">
    <img class="bg_result" src="./images/bg_result.png">
    <div class="container">
      <img class="real_man" src="./images/real_man.png">
      <img class="real_character" src="./images/real_character.png">
    </div>
  </div>
  <div class="wrapper-5 bg-white text-center">
    <div class="testimonial_pane bg-lightgrey pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/actor_3.png">
          <div class="badge_pane d-flex align-center">
            <img class="badge" src="./images/badge.png">
            <p class="badge_text mb-15">Verified Customer</p>
          </div>
          <img class="stars" src="./images/stars.png">
        </div>
        <div class="description_part grey text-left">
          <h3 class="bold mt-0 mb-15">Wow, this stuff really worked!</h3>
          <p class="testimonial_des red bold mt-0">GAINED 3 INCHES</p>
          <p class="description">“Superior Male is my 5th enlargement supplement, and this is the only stuff that worked for me. I found out my doctor was taking Superior Male, so I had to give it a shot. Now, when women unzip my pants, they see a rock-hard 8-inch-long fat penis staring them in the face. The look on their face is always priceless!”</p>
          <p class="description italic d-flex">— Matt Mueller<span class="desktop-only mr-5">, </span><br class="mobile-only"> Montgomery, AL. 31 years old</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/actor_4.png">
          <div class="badge_pane d-flex align-center">
            <img class="badge" src="./images/badge.png">
            <p class="badge_text mb-15">Verified Customer</p>
          </div>
          <img class="stars" src="./images/stars.png">
        </div>
        <div class="description_part grey text-left">
          <h3 class="bold mt-0 mb-15">Massive gains in just 3 weeks!</h3>
          <p class="testimonial_des red bold mt-0">GAINED 2.7 INCHES</p>
          <p class="description">“It nearly drove me insane when I found out that my girlfriend bought a massive black sex toy because she missed having sex with a bigger penis. I just had to do something about it – and FAST, before she gets the appetite to try the real thing. I got Superior Male, and it worked way faster than I expected. I took it every day, so now we get to have sex more than 3 times a day, and her sex toy is just gathering dust somewhere under our bed.”</p>
          <p class="description italic d-flex">— Keith Matthews<span class="desktop-only mr-5">, </span><br class="mobile-only"> Seattle, WA. 28 years old.</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane bg-lightgrey pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/actor_5.png">
          <div class="badge_pane d-flex align-center">
            <img class="badge" src="./images/badge.png">
            <p class="badge_text mb-15">Verified Customer</p>
          </div>
          <img class="stars" src="./images/stars.png">
        </div>
        <div class="description_part grey text-left">
          <h3 class="bold mt-0 mb-15">They can’t get enough of it!</h3>
          <p class="testimonial_des red bold mt-0">GAINED 2.5 INCHES</p>
          <p class="description">“I was a month away from getting married to my high school girlfriend when I found out that she has been cheating on me with some guy she met at her bachelorette party. Her best friend told me that the guy was hung, and they couldn’t stop her from going after the guy. I decided my best revenge would be to take Superior Male and have sex with as many women as I could. I started with her best friend, then her sister, then her cousin, and just to wrap up my sick family streak, I had her mom suck me off. Best revenge ever.” </p>
          <p class="description italic d-flex">— Pete Wagner<span class="desktop-only mr-5">, </span><br class="mobile-only"> Newark, NJ. 30 years old</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/actor_6.png">
          <div class="badge_pane d-flex align-center">
            <img class="badge" src="./images/badge.png">
            <p class="badge_text mb-15">Verified Customer</p>
          </div>
          <img class="stars" src="./images/stars.png">
        </div>
        <div class="description_part grey text-left">
          <h3 class="bold mt-0 mb-15">Asian girls beware</h3>
          <p class="testimonial_des red bold mt-0">GAINED 3.5 INCHES</p>
          <p class="description">“I’ve had been using Superior Male for about two months before I went on a vacation in South Korea. I bought a bottle with me, and I just had to see what Korean women were like. I didn’t expect them to be as loose as American women, but they were small and extremely tight during sex! I’d go home with different women each time, and none of them had a 9-inch long American penis before! If you take Superior Male and go to any Asian country, I guarantee your penis will be worshipped like a god!”</p>
          <p class="description italic d-flex">— Carl Johnson<span class="desktop-only mr-5">, </span><br class="mobile-only"> Dallas, TX. 34 years old.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="wrapper-6 pt-30 pb-60">
    <img class="bg_trophy desktop-only" src="./images/bg_trophy.png">
    <img class="bg_trophy mobile-only" src="./images/bg_trophy_mobile.png">
    <div class="container">
      <div class="trophy_pane d-flex align-center">
        <img class="trophy desktop-only" src="./images/trophy.png">
        <img class="trophy mobile-only" src="./images/trophy_mobile.png">
        <div class="trophy_description white text-center">
          <span class="trophy_des uppercase pt-60 bold">You’ve heard it from real Superior Male users</span>
          <p class="medium">Now, see why 30 supplement websites rank Superior Male as <br class="desktop-only"> the #1 natural enlargement supplement</p>
        </div>
      </div>
    </div>
  </div>
  <div class="wrapper-7 bg-lightgrey section-space">
    <div class="container">
      <div class="item-wrapper">
        <div class="item_pane">
          <div class="intro_pane">
            <img class="first" src="./images/item_5.png">
            <p class="description blue mobile-only pt-15">www.nutramanix.com</p>
            <div class="star_pane d-flex flex-direction-column align-center desktop-only">
              <span class="star_mark">5.0</span>
              <img class="stars" src="./images/stars.png">
            </div>
          </div>
          <p class="description">We’re always skeptical when we review a product that claims to increase penis size. Before Superior Male, we never came across a real natural enlargement supplement. Everything else was just a fluke. We studied the ingredients, made comparisons, and we actually tried the product. That’s how we know Superior Male is legit because it looked good on paper, but its real-life results go way beyond your imagination.</p>
          <p class="description blue desktop-only pt-15">www.nutramanix.com</p>
          <div class="d-flex flex-direction-column align-center mobile-only">
            <span class="star_mark">5.0</span>
            <img class="stars" src="./images/stars.png">
          </div>
        </div>
        <div class="item_pane mt-30">
          <div class="intro_pane">
            <img src="./images/item_6.png">
            <p class="description blue pt-15 mobile-only">www.maxfitnesstoday.com</p>
            <div class="star_pane d-flex flex-direction-column align-center desktop-only">
              <span class="star_mark">5.0</span>
              <img class="stars" src="./images/stars.png">
            </div>
          </div>
          <p class="description">Superior Male was the easiest supplement to review. It has everything we want in a natural enlargement supplement. <br>It has the science, the ingredients, and the quality that we all want to see. We ran Superior Male through the toughest of tests, and we even ran a pill through our spectrum analyzer, and everything checked out! This is the most impressive supplement we have ever come across! </p>
          <p class="description blue pt-15 desktop-only">www.maxfitnesstoday.com</p>
          <div class="d-flex flex-direction-column align-center mobile-only">
            <span class="star_mark">5.0</span>
            <img class="stars" src="./images/stars.png">
          </div>
        </div>
        <div class="item_pane mt-30">
          <div class="intro_pane">
            <img src="./images/item_7.png">
            <p class="description blue pt-15 mobile-only">www.healthymensinfo.com</p>
            <div class="star_pane d-flex flex-direction-column align-center desktop-only">
              <span class="star_mark">5.0</span>
              <img class="stars" src="./images/stars.png">
            </div>
          </div>
          <p class="description">We all thought Superior Male was too good to be true until we actually saw and tried the pill. Every review we’ve seen about Superior Male so far has been accurate. This thing delivers real results. We have 5 guys on our staff who tried Superior Male, and all of them gained more than 2 inches in just a few weeks of taking Superior Male! I mean, what else could possibly beat that?</p>
          <p class="description blue pt-15 desktop-only">www.healthymensinfo.com</p>
          <div class="d-flex flex-direction-column align-center mobile-only">
            <span class="star_mark">5.0</span>
            <img class="stars" src="./images/stars.png">
          </div>
        </div>
        <div class="item_pane mt-30">
          <div class="intro_pane">
            <img src="./images/item_8.png">
            <p class="description blue pt-15 mobile-only">www.totalmenslifestyle.com</p>
            <div class="star_pane d-flex flex-direction-column align-center desktop-only">
              <span class="star_mark">5.0</span>
              <img class="stars" src="./images/stars.png">
            </div>
          </div>
          <p class="description">Normally, we expose enlargement pills for their fraudulent claims, and we thought Superior Male was just another product of the same mold. We studied the formula, we analyzed the ingredients, and we tested the pills ourselves. Everything we’ve seen tells us that this stuff is 100% real. We gained size. We experienced results. We don’t need samples. We’re buying an entire box of this stuff!</p>
          <p class="description blue pt-15 desktop-only">www.totalmenslifestyle.com</p>
          <div class="d-flex flex-direction-column align-center mobile-only">
            <span class="star_mark">5.0</span>
            <img class="stars" src="./images/stars.png">
          </div>
        </div>
        <div class="item_pane mt-30">
          <div class="intro_pane">
            <img src="./images/item_9.png">
            <p class="description blue pt-15 mobile-only">www.topsupplementsnow.com</p>
            <div class="star_pane d-flex flex-direction-column align-center desktop-only">
              <span class="star_mark">5.0</span>
              <img class="stars" src="./images/stars.png">
            </div>
          </div>
          <p class="description">After reviewing thousands of supplements, we know for a fact that Superior Male is the only natural enlargement supplement that works. Our team examined every bit of scientific reference, research, and study involving Superior Male’s ingredients, and everything clearly checks out. This is something that no other supplement in the industry can replicate. This is the real deal. </p>
          <p class="description blue pt-15 desktop-only">www.topsupplementsnow.com</p>
          <div class="d-flex flex-direction-column align-center mobile-only">
            <span class="star_mark">5.0</span>
            <img class="stars" src="./images/stars.png">
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="wrapper-8 pb-60">
    <img class="bg_effect8 desktop-only" src="./images/bg_effect8.png">
    <img class="bg_effect8 mobile-only" src="./images/bg_effect8_mobile.png">
    <img class="bg_document desktop-only" src="./images/bg_document.png">
    <img class="bg_document mobile-only" src="./images/bg_document_mobile.png">
    <div class="container">
      <div class="effect_pane white">
        <div class="effect_des">
          <span class="medium">The<br></span>
          <span class="title-2 bold">REAL SUPERIOR MALE<br><span class="effect_font">Advantage</span></span>
        </div>
        <img class="bottle" src="./images/bottle.png">
      </div>
      <div class="document_pane d-flex pt-120">
        <div class="mr-30">
          <p class="description">Not all enlargement supplements are the same. Some supplement brands will try to trick you into believing that their product works, but only premium, high-quality supplements are backed by actual science and use high-grade, scientifically validated ingredients. <br class="mobile-only mt-30"></br> Dosage, ingredient quality, and potency are all crucial in ensuring that you get the results you want, but to create a real natural enlargement supplement, you need an extremely powerful formula that goes beyond the conventional limits of supplements. </p>
        </div>
        <img class="research" src="./images/research.png">
      </div>

      <p class="description">We spent the last 10 years perfecting our formula. We worked tightly with industry experts, leaders, scientists, and innovators to create a breakthrough supplement that can guarantee an increase in erection length, girth, and hardness.</p>
      <p class="description">No one has to explain why men want to have a bigger erection – we all understand why it’s important. We all understand that bigger penises make women experience extreme pleasure from sex. We know that women lust over men with bigger erections. We know that having a bigger erection will erase every insecurity a man may have – and that’s why it needs to be done.</p>
      <p class="description">We traveled to more than 20 countries in our search for the perfect ingredients for Superior Male, and we worked with the leading biochemists and botanists to maximize the extraction and potency of every ingredient. Superior Male is the first and ONLY supplement in the market that features the extreme level of potency, quality, and performance that ensures mind-blowing results.</p>
      
      <p class="title pt-30 pb-30">Accelerated Expansion Technology</p>
      <div class="document_pane d-flex">
        <div class="mr-30">
          <p class="description mt-0">No man can wait for months to get results as exciting as having a larger erection. That’s why we optimized our formula to greatly increase the bioavailability of the ingredients and maximize the impact of Superior Male in your system.</p>
          <p class="description">T-Levels greatly influence a man’s sexual performance, from sex drive to erection quality. Superior Male’s formula features the strongest core t-boosting formula, which impacts all major test-boosting pathways.</p>
        </div>
        <img class="research" src="./images/actor_7.png">
      </div>

      <p class="description">This allows the body to quickly react to the rapid increase in t-levels and develop a massive boost in sex drive, energy, stamina, and sexual performance. Superior Male also uses key components that preserve high t-levels and reduce test breakdown to ensure that you maintain high t-levels throughout. </p>
      <p class="description">Superior Male’s strong t-level-boosting complex is further amplified by potent nitric oxide boosters and PDE-5 inhibitors. As you experience sexual arousal, the signals from the brain are amplified to channel blood flow to the penis. This reaction causes an erection, which is further maximized by vasodilators that allow the penile artery and cavernous spaces in the penis to expand.
      </p>
    </div>
  </div>
  <div class="wrapper-9 section-space">
    <img class="bg_wrapper9" src="./images/bg_wrapper9.png">
    <div class="pt-30 white text-center">
      <p class="title-3 bold uppercase">Superior Male’s Accelerated Expansion Technology</p>
      <p class="title lightgrey uppercase position-relative pb-30">allows men to experience mind-blowing results almost instantly.</p>
      <p class="container description pt-15">The formula greatly impacts the body’s reaction to sexual stimuli, and this results in an astonishing increase in erection LENGTH, GIRTH, and HARDNESS. That’s why we are 100% confident that you’ll experience the BEST SEX OF YOUR LIFE when you take Superior Male.</p>
    </div>
  </div>
  <div class="wrapper-10">
    <img class="bg_table" src="./images/bg_table.png">
    <img class="d-flex mobile-only table" src="./images/table_mobile.png">
    <div class="container pt-30 pb-30">
      <img class="d-flex desktop-only table" src="./images/table.png">
    </div>
  </div>
  <div class="wrapper-11 text-center bg-lightgrey">
    <img class="bg_source desktop-only" src="./images/bg_source.png">
    <img class="bg_source mobile-only" src="./images/bg_source_mobile.png">
    <div class="source_des container pt-60 pb-60 text-center white">
      <p class="title-4 pt-30 pb-30 uppercase bold">Superior Male Ingredients</p>
      <p class="title">Superior Male features the best performinzg natural ingredients to give you the SIZE, STAMINA, and SEX DRIVE you need to experience the BIGGEST and HARDEST erections.</p>
    </div>
    <div class="testimonial_pane mobile-space pt-120 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_1.png">
        </div>
        <div class="description_part text-left">
          <p class="description mb-0 bold">Horny Goat Weed <br class="mobile-only">(Epimedium Grandiforum)</p>
          <p class="description mt-0">Horny Goat Weed is a therapeutic herb used in Traditional Chinese medicine as a treatment for impotence and infertility. The herb itself is native to China, but it is now also found in some places in the Mediterranean and the Himalayas. Our research shows that Horny Goat Weed contains a potent erectogenic and sex drive booster called Icariin, which can only be obtained by purifying the roots of the herb. Superior Male contains the highest purification of Horny Goat Weed, with the highest concentrations of Icariin to maximize sex drive, stamina, and penis size. </p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane bg-grey pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_2.png">
        </div>
        <div class="description_part text-left">
          <p class="description mb-0 bold">Tongkat Ali (Eurycoma Longifolia)</p>
          <p class="description mt-0">Tongkat Ali is a powerful herbal medicine found only in parts of Indonesia, Malaysia, Thailand, and the Philippines. The plant has been used traditionally to induce erections, and we have found that the herb has the highest concentrations of the phytochemical compound 9-hydroxycanthin-6-one, which makes it easier for men to obtain an erection, and it also prolongs and intensifies erections. Tongkat Ali is also one of the best ingredients to boost t-levels as it helps to rapidly increase test production, and it has properties that maintain high t-levels for a long time.</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_3.png">
        </div>
        <div class="description_part text-left">
          <p class="description mb-0 bold">Saw Palmetto (Seronoa Repens)</p>
          <p class="description mt-0">Saw Palmetto is a widely used herb in alternative medicine as a health and performance booster for bodybuilders, athletes, and fitness enthusiasts. Our research shows that Saw Palmetto’s active compounds focus on the metabolism of t-levels, which allows the formula to drastically improve and accelerate test production and allows the body to retain high t-levels for maximum sex drive and performance.</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane bg-grey pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_4.png">
        </div>
        <div class="description_part text-left">
          <p class="description mb-0 bold">Orchic Substance</p>
          <p class="description mt-0">Orchic extract is sourced from high-quality bull testes as a tonic for improved physical and sexual performance. Our research shows that bull testes are high in minerals and compounds that greatly intensify test production and sex drive.</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_5.png">
        </div>
        <div class="description_part text-left">
          <p class="description mb-0 bold">Sarsaparilla Root Extract</p>
          <p class="description mt-0">Sarsaparilla extract is best known for its use as a flavoring for beverages and is most commonly found in parts of Southeast Asia. Recent studies show that Sarsaparilla has a strong libido-boosting component that helps the formula sustain high t-levels, and this gives the user the ability to gain rock-hard erections with ease.</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane bg-grey pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_6.png">
        </div>
        <div class="description_part text-left">
          <p class="description mb-0 bold">Nettle Root Extract</p>
          <p class="description mt-0">Stinging nettle is an intense sexual enhancement ingredient that allows the user to experience intense sexual desire and erections. The ingredient supports the Superior Male formula by increasing free and total t-levels, which allow for faster, more robust erections.</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane pt-60 pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_7.png">
        </div>
        <div class="description_part text-left">
          <p class="description mb-0 bold">Boron Amino Acid Chelate </p>
          <p class="description mt-0">Boron Amino Acid Chelate is focused on enhancing the user’s mood by reducing stress and anxiety, which could drastically impact sexual performance. The ingredient virtually eliminates the factor of performance anxiety during sex, and this maximizes the pleasure and satisfaction felt during sexual intercourse.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="wrapper-12 text-center">
    <img class="bg_wrapper12" src="./images/bg_wrapper12.png">
    <div class="container pt-60 pb-60 text-center">
      <h2>IS <span class="lightgrey">SUPERIOR MALE</span> THE <br><span class="red">RIGHT</span> SUPPLEMENT<br> FOR YOU?</h2>
      <img class="pro_bottle mobile-only" src="./images/pro_bottle.png">
      <div class="pro_section section-space">
        <div class="pro_left_section">
          <div class="pro_pane">
            <img class="pro_img" src="./images/pro_94.png">
            <p class="description bold">OF MEN EXPERIENCE <span class="red">HARDER</span> ERECTIONS WITHIN 5 DAYS</p>
          </div>
          <div class="pro_pane">
            <img class="pro_img" src="./images/pro_96.png">
            <p class="description bold">OF MEN EXPERIENCE <span class="red">BETTER SEXUAL PLEASURE</span> IN JUST THE FIRST DOSE</p>
          </div>
        </div>
        <img class="pro_bottle desktop-only" src="./images/pro_bottle.png">
        <div class="pro_pane mobile-only">
          <img class="pro_img" src="./images/pro_89.png">
          <p class="description bold">OF MEN OVER 40 REGAIN THEIR <span class="red">BEST SEXUAL PERFORMANCE</span> IN JUST 7 DAYS</p>
        </div>
        <div class="pro_right_section">
          <div class="pro_pane">
            <img class="pro_img" src="./images/pro_92.png">
            <p class="description bold">OF MEN EXPERIENCE <span class="red">LARGER </span> ERECTIONS WITHIN 14 DAYS</p>
          </div>
          <div class="pro_pane">
            <img class="pro_img" src="./images/pro_90.png">
            <p class="description bold">OF MEN <span class="red">CUM MORE THAN ONCE</span> DURING SEX AFTER TAKING SUPERIOR MALE FOR 7 DAYS</p>
          </div>
        </div>
        <div class="pro_pane last desktop-only">
          <img class="pro_img" src="./images/pro_89.png">
          <p class="description bold">OF MEN OVER 40 REGAIN THEIR <span class="red">BEST SEXUAL PERFORMANCE</span> IN JUST 7 DAYS</p>
        </div>
      </div>
      <div class="clearfix"></div>
    </div>
  </div>
  <div class="wrapper-13">
    <img class="bg_wrapper13" src="./images/bg_wrapper13.png">
    <div class="container">
      <div class="effect_pane d-flex align-center white">
        <div class="effect_des d-flex flex-direction-column">
          <img class="logo" src="./images/logo_reverse.png">
          <h2 class="text-left pt-30 pb-30">IS THE <span class="yellow">#1 MOST <br>TRUSTED SUPPLEMENT</span><br class="desktop-only"> FOR MAXIMUM ERECTION SIZE AND HAPPINESS </h2>
          <p class="description semibold mt-0">Rated #1 Enlargement Supplement by<br class="desktop-only"> more than 30 different websites</p>
        </div>
        <img class="bottle_twice desktop-only" src="./images/bottle_twice.png">
        <img class="bottle_twice mobile-only" src="./images/bottle_twice_mobile.png">
      </div>
    </div>
  </div>
  <div class="wrapper-14 section-space bg-lightgrey">
    <div class="testimonial_pane section-space">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_8.png">
        </div>
        <div class="description_part text-left">
          <p class="title-5 mb-0 bold">BREAKTHROUGH<br class="mobile-only"> FORMULATION</p>
          <p class="description mt-0">Superior Male is the only supplement that features the cutting-edge Accelerated Expansion Technology, a landmark technology that allows test boosters and vasodilators to synergize seamlessly to achieve a dramatic increase in erection length, girth, and hardness. Superior Male developed the Accelerated Expansion Formula for years, and now men get the final product – a premium-quality supplement that can guarantee the biggest and hardest erections of your life.</p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_9.png">
        </div>
        <div class="description_part text-left">
          <p class="title-5 mb-0 bold">INTENSE LIBIDO AND<br class="mobile-only"> ENDURANCE</p>
          <p class="description mt-0">Superior Male’s core complex features the most advanced t-level-boosting formula that instantly fires up your sex drive, giving you an insane boost to your sexual performance. Superior Male is the only supplement that is fully equipped with the highest potency ingredients that allow you to achieve FAST and EFFECTIVE results starting from the first dose. </p>
        </div>
      </div>
    </div>
    <div class="testimonial_pane pb-60">
      <div class="container d-flex align-center">
        <div class="image_part d-flex">
          <img src="./images/source_10.png">
        </div>
        <div class="description_part text-left">
          <p class="title-5 mb-0 bold">100% MONEY-BACK<br class="mobile-only"> GUARANTEE</p>
          <p class="description mt-0">We set the highest standards to ensure that every customer gains the maximum boost to their libido, energy, stamina, sexual performance, and erection size. That’s why we are 100% confident that you’ll be completely satisfied with the results that you will get. All purchases are covered by our industry-leading 100% money-back guarantee. On the off chance that you are not completely satisfied with your results, you can simply call our hotline any day of the week, and we’ll refund 100% of the purchase price. That’s a promise!</p>
        </div>
      </div>
    </div>
  </div>
  <div class="wrapper-15 section-space bg-lightgrey">
    <div class="tile_pane">
      <img class="bg_tile" src="./images/bg_tile.png">
    </div>
    <div class="container position-relative d-flex white">
      <div class="description_part d-flex flex-direction-column align-center text-center">
        <p class="title-3">GET THE SIZE,<br class="mobile-only"> STAMINA, and SEX DRIVE YOU NEED</p>
        <p class="title-6 bg-red bold mb-0">Experience the BIGGEST and HARDEST Erection of Your Life</p>
        <p class="title-5 italic">Superior Male with Accelerated Expansion Technology</p>
        <div class="grid-wrapper">
          <div class="grid_pane">
            <img class="check" src="./images/check.png">
            <p class="grid_des bold">Most Powerful Penis Enlargement Ingredients</p>
          </div>
          <div class="grid_pane">
            <img class="check" src="./images/check.png">
            <p class="grid_des bold">Increase Length and Girth</p>
          </div>
          <div class="grid_pane">
            <img class="check" src="./images/check.png">
            <p class="grid_des bold">Boost Sex Drive and Performance</p>
          </div>
          <div class="grid_pane">
            <img class="check" src="./images/check.png">
            <p class="grid_des bold">Improve Erection Quality</p>
          </div>
        </div>
      </div>
      <div class="image_part d-flex flex-direction-column align-center">
        <img class="desktop-only" src="./images/bottle_shipping.png">
        <img class="mobile-only" src="./images/bottle_shipping_mobile.png">
        <img class="five_stars" src="./images/5_stars.png">
        <p class="title-5 text-center yellow">Superior Male is the #1 Rated 5 Star Penis Enlargement Suppement by multiple supplement review sites</p>
      </div>
    </div>
    <div class="cta_pane d-flex justify-content-center possition_relative">
      <a href="./order">
        <button class="order-btn">
          <span>CLICK TO SEE</span>
          <span class="grid_des medium">Limited Time Special Offer</span>
        </button>
      </a>
    </div>
  </div>
</div>
<?php
$this->params['data']['script'] = <<<EOT
EOT;
?>