<?php
use app\helpers\UtilityHelper;
$this->params['data'] = ['page' => 'home', 'title' => 'Home'];
?>
<!-- Section 1 -->
<section class="section-1">
  <div class="container text-center">
    <h1>Instantly Add Size To Your Penis Guaranteed</h1>
  </div>
</section>
<!-- Section 2 -->
<section class="section-2">
  <div class="container">
    <h2>PRIMANIX Male Enhancement pills</h2>
    <div class="details">
      <div class="row item mb-4 no-gutters align-items-center">
        <div class="col-md-3 col-lg-2 image text-center pr-4 mb-3 mb-md-0">
          <img src="/images/seal.png" alt="" class="img-fluid">
        </div>
        <div class="col-md-9 col-lg-10 body">
          <p class="mb-0"><strong>Primanix is Clinically Tested</strong> - The key high-potency compounds in Primanix male enhancement supplements are supported by numerous clinical studies showing the compounds in this Multi-Active formula can transform your manhood like no other male enhancement pill. Our superior formula design, engineering and delivery system have rocketed Primanix into the breakthrough enhancement product that is sweeping the nation.</p>
        </div>
      </div>
      <div class="row item mb-4 no-gutters align-items-center">
        <div class="col-md-3 col-lg-2 image text-center pr-4 mb-3 mb-md-0">
          <img src="/images/seal.png" alt="" class="img-fluid">
        </div>
        <div class="col-md-9 col-lg-10 body">
          <p class="mb-0">The Ingredients within Primanix’s <strong>Advance Syner-Boost Expansion Formula</strong> have been clinically tested and proven to <strong>Increase Penile Tissue by a shocking 44%.</strong> Imagine Life with a penis nearly 50% bigger with Primanix!</p>
        </div>
      </div>
      <div class="row item no-gutters align-items-center">
        <div class="col-md-3 col-lg-2 image text-center pr-4 mb-3 mb-md-0">
          <img src="/images/seal.png" alt="" class="img-fluid">
        </div>
        <div class="col-md-9 col-lg-10 body">
          <p class="mb-0"><strong>Primanix’s Accelerated-Expansion Formula</strong> rapidly increases the delivery of blood and key nutrients to the penis, giving you a <strong>Larger, Thicker and Overall Massive Penis</strong>. Join the Thousands of Men that have tried <strong>Primanix’s Breakthrough</strong> Formula for male enhancement.</p>
        </div>
      </div>
    </div>
    <p class="note text-center mt-4 mb-5">*Individual Results May Vary</p>
    <div class="banner-image text-center">
      <img src="/images/home/s2-image1-mb.jpg" alt="" class="img-fluid d-block w-100 d-md-none">
      <img src="/images/home/s2-image1-dk.jpg" alt="" class="img-fluid d-none d-md-block">
    </div>
  </div>
</section>
<!-- Section 3 -->
<section class="section-3">
  <div class="container">
    <div class="main-row mb-5">
      <h2>Scroll Down To Order Now</h2>
      <h3>Men With Bigger Penises Enjoy Life More…</h3>
      <p><strong>Studies have shown that men who take Primanix male enhancement pills can have larger, thicker penises and have more sex with women.</strong> With Primanix and a bigger penis, your confidence will explode, your life will improve in every way, and women will be falling all over you.</p>
      <p><strong>Studies also show that women are more likely to stay with a man who has a huge and thick penis and can satisfy them.</strong> Having a harder, bigger, and more impressive penis will not only make your sex life EXPLODE, but your daily life will never be better.</p>
      <p><strong>One customer of Primanix realized how much better his life was when using male enhancement pills like Primanix, and with his bigger, thicker penis, he was able to sleep with the CEO of his company,</strong> who is one of the hottest and richest women in his industry. Because of Primanix and his now larger penis, he is now the CFO of a large technology company in California making over a million dollars per year.</p>
      <p><strong>With Primanix male enhancement pills as your secret weapon,</strong> you’ll not only add size to your penis, but you’ll be able to ejaculate more, give your women a mind-blowing orgasm, and with all that added confidence you’ll be having sex with more women than you ever imagined. Prepare yourself, because with Primanix you’ll finally know what it feels like to have women BEG and SCREAM for you to keep going because of your gigantic penis.</p>
      <p class="note mt-4">*Individual Results May Vary</p>
    </div>
    <div class="panel mb-4">
      <div class="head">
        <h3>SIZE MATTERS</h3>
      </div>
      <div class="body">
        <div class="row">
          <div class="col-lg-5 mb-3 mb-lg-0 order-lg-2">
            <img src="/images/home/s3-image1.jpg" alt="" class="img-fluid">
          </div>
          <div class="col-lg-7 order-lg-1">
            <div class="text">
              <p>Say what you will about penis size, but there’s one undeniable truth: <strong>if it comes down to size, women would have sex with a man with a bigger penis.</strong></p>
              <h4 class="mb-4">SEE WHAT WOMEN HAD TO SAY ABOUT PENIS SIZE AND Primanix:</h4>
              <ul>
                <li>95% SAID that SEX IS MUCH MORE ENJOYABLE with a big penis</li>
                <li>91% SAID that they are disappointed when they see a small penis</li>
                <li>70% SAID that they have dumped someone in favor of a man with a BIG penis</li>
                <li>97% SAID Primanix male enhancement pills dramatically enhanced sex</li>
                <li>85% SAID that they would rather be with a man with a BIG penis</li>
                <li>89% SAID that rumors about a guy’s penis size makes them curious enough to have sex</li>
                <li>90% SAID that women share and talk about men with big penises</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="other-row">
      <h5>Clinically Tested To Be Bigger - Be Harder - Last Longer - Ejaculate More - Have More Erections</h5>
      <div class="text-center mt-4">
        <p class="note mb-4">*Individual Results May Vary</p>
        <img src="/images/home/s3-image2.jpg" alt="" class="img-fluid">
      </div>
    </div>
  </div>
</section>
<!-- Section 4 -->
<section class="section-4">
  <div class="container">
    <h2>How Primanix Will Work:</h2>
    <p class="h2-sub">5 Stages to a Larger, Thicker, Fuller Penis</p>
    <div class="stages">
      <div class="row justify-content-center">
        <div class="col-md-6 col-lg-4">
          <div class="card">
            <h3>Stage 1:</h3>
            <p class="mb-0 text-start text-lg-center">Fast-acting aphrodisiacs and PDE-5 inhibitors are absorbed by the body in just 30 minutes after taking the first dose of Primanix. The effects of aphrodisiacs and PDE-5 inhibitors supercharge the user’s libido and enhances the intensity and hardness of the user’s erections.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="card">
            <h3>Stage 2:</h3>
            <p class="mb-0 text-start text-lg-center">Delayed-release aphrodisiacs and PDE-5 inhibitors remain active to ready the body for sexual activities for 24 hours. Vasodilator ingredients in Primanix increase the flow of blood to the penis, setting the conditions for continuous penis enlargement.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="card">
            <h3>Stage 3:</h3>
            <p class="mb-0 text-start text-lg-center">While the user experiences an erection, the PDE-5 inhibitor ingredients in Primanix enhance the effects of the vasodilators to maximize the amount of blood supplied to the cavernous spaces in the penis, which would trigger an expansion of penile tissue permanently.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="card">
            <h3>Stage 4:</h3>
            <p class="mb-0 text-start text-lg-center">The increased volume of blood that fills the corpora cavernosa, or the penile chambers will cause the penile chambers to acclimatize and expand, consequentially creating a permanently bigger penis.</p>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="card">
            <h3>Stage 5:</h3>
            <p class="mb-0 text-start text-lg-center">Testosterone stabilization allows the body to increase the instances of erections by minimizing the effects of the refractory period in the body to prolong and maximize the penis enlarging effects of Primanix.</p>
          </div>
        </div>
      </div>
    </div>
    <p class="note my-4 text-center">*Individual Results May Vary</p>
    <div class="images text-center">
      <img src="/images/banner-image.jpg" alt="" class="img-fluid mb-4">
      <img src="/images/home/s4-image2-mb.jpg" alt="" class="img-fluid d-block w-100 d-md-none">
      <img src="/images/home/s4-image2-dk.jpg" alt="" class="img-fluid d-none d-md-block">
    </div>
    
  </div>
</section>
<!-- Section 5 -->
<section class="section-5">
  <div class="container">
    <div class="testimonials owl-carousel mb-5">
      <div class="item">
        <h4 class="text-center">“Prepare yourself for something intense.”</h4>
        <p>I’ve never had many male enhancement supplements, but PRIMANIX definitely takes the cake. All the other penis enlargement pills I’ve tried were all sawdust compared to this one. After my first dose, I can immediately tell that something is going on. If it weren’t for the clear and honest facts that they published on their website, I would have believed that PRIMANIX was able to make my penis big in just one day. I’ve used PRIMANIX for a month, and I’ve added more than 2 inches to my penis, but the real change is in my girth. I suppose I added more than an inch, but it could be more since it just feels so thick now. Can’t say I’m not impressed! Good job, PRIMANIX!</p>
        <div class="author">~ Andrew M. Chicago, IL</div>
      </div>
      <div class="item">
        <h4 class="text-center">“PRIMANIX IS ONE OF THE BEST MALE ENHANCEMENT PILLS I HAVE EVER TRIED”</h4>
        <p>After just a few short weeks, I saw HUGE increases in penis size, MASSIVE increases in semen volume and sex-drive, and more stamina than I know what to do with. If you have ever wanted to have a horse cock and FUCK like a horse at the same time, Primanix is the key you’ve been missing. Forget about all of those garbage male enhancement supplements that don’t work and just get Primanix and see REAL RESULTS!!</p>
        <div class="author">~ Robert T. Syracuse, NY</div>
      </div>
      <div class="item">
        <h4 class="text-center">“PRIMANIX is exactly what you’ve been looking for.”</h4>
        <p>If you’ve tried other male enhancement pills and saw no results, then Primanix is exactly what you’ve been looking for. This stuff KICK ASS. I’ve seen my penis grow several inches in just a few short weeks, and my stamina is so high that I can have sex for hours and not break a sweat. My wife has no idea what happened to me. I’m like a new man overnight! Primanix is the only product I have tried that actually delivers on the claims it promises. Everything else out there is a total lie and doesn’t work. If you actually want a bigger dick and more energy in bed, Primanix is pill to buy.</p>
        <div class="author">~ Bill J. – San Francisco, CA</div>
      </div>
      <div class="item">
        <h4 class="text-center">“Getting a bigger dick has never been easier with PRIMANIX”</h4>
        <p>It has high-potency ingredients that go to work immediately, and this is an instant size increaser. Because the ingredients are so incredibly powerful, you also see massive erections, tons of sexual energy, more sex-drive, and my testosterone levels are extremely high. You have to try it for yourself to believe it. It’s pretty amazing how well Primanix works. Other male enhancement pills don’t even work half as well as Primanix, and I have tried basically everything before getting to this point. Truly a masterpiece of a product!</p>
        <div class="author">~ Chris L. - Atlanta, GA</div>
      </div>
      <div class="item">
        <h4 class="text-center">“PRIMANIX is the real deal!”</h4>
        <p>My girlfriend says I look literally twice as big now after using it, and my sex-drive is miles ahead of where it used to be. If you miss feeling like a teenager, this stuff will give you some serious nostalgia. I feel like I can screw 5 times a day now, and with more intensity that I even remember. I’m in love with this product. Male enhancement pills like Primanix do not come around too often, and you better grab it before it’s all gone. It’s the gold bar of the male enhancement industry!</p>
        <div class="author">~ Peter G. – Chicago, IL</div>
      </div>
      <div class="item">
        <h4 class="text-center">The last male enhancement pill for me!</h4>
        <p>Check this out – I’ve been buying male enhancement pills for the last 3 years. I spent thousands of dollars trying to make myself bigger – and I only got real results with Primanix. Don’t bother buying other male enhancement pills that only spike your libido for a bit. Primanix gives you REAL results. I’ve only used Primanix for the last two months, and my size and libido have never been better. Primanix is the last male enhancement pill for me. If you want real results without spending thousands of dollars like I did in the past, then you should give Primanix a shot.</p>
        <div class="author">~ Matt C. - Seattle, WA</div>
      </div>
      <div class="item">
        <h4 class="text-center">I didn’t know I could get this big!</h4>
        <p>I’ve always wanted to take male enhancement pills, but I’ve never got around to ordering one. I read about Primanix and finally pulled the trigger. Since I’ve read so much negative articles about male enhancement, I wasn’t expecting much from Primanix. I took Primanix for about a month when I noticed that I was getting bigger erections. I added an inch to my length and girth. I’ve been taking Primanix for the last 90 days, and I’m way bigger than I was before. My sex life is at an all-time high, and ladies are easy to impress in bed. Are all male enhancement pills this good? I doubt it.</p>
        <div class="author">~ Will S. - Los Angeles, CA</div>
      </div>
      <div class="item">
        <h4 class="text-center">No blue pill? No problem.</h4>
        <p>I’ve used the blue pill for about two years when I learned about Primanix. The blue pill definitely gave me good erections, but Primanix did something way better – I got bigger erections. Not only that, Primanix also boosted my libido, and made me a lot better in bed. The best part of this experience is the fact that Primanix only costs a fraction of what I used to spend on the blue pills. For a little bit more than a dollar a day, I can get Primanix daily. It’s simply the best male enhancement pill for me, and it would probably take years before the supplement companies would come up with something better.</p>
        <div class="author">~ Steve T. - Chicago, IL</div>
      </div>
      <div class="item">
        <h4 class="text-center">Affordable and effective!</h4>
        <p>I retired when I was 55, and got divorced before my 56th birthday. There just wasn’t anything to do. I thought I was too old to date, to get women – until an old buddy of mine talked me into buying Primanix. At first I thought it was a scam. I thought nothing this affordable could be THAT effective. I took Primanix daily, and I felt the changes almost immediately. I gained around 1.5 inches in my first month! I retired with a bit of cash, and it definitely helps that Primanix doesn’t cost an arm and a leg like other pills do. Plus, it made my sex life a whole lot better. I’m going out like I was in my 30s, and young ladies come up to me almost on a nightly basis, especially when they heard I was packing something big inside my pants. I never thought life could be this sweet. Thanks, Primanix!</p>
        <div class="author">~ Laurie C. - Miami, FL</div>
      </div>
    </div>
    <div class="panel mb-5">
      <div class="head text-center text-lg-start">
        <h3>Experience Primanix and Get Real Results</h3>
      </div>
      <div class="body">
        <div class="row align-items-center">
          <div class="col-lg-3 mb-3 mb-lg-0 order-lg-2">
            <div class="image mx-auto">
              <img src="/images/money-back.jpg" alt="" class="img-fluid">
            </div>
          </div>
          <div class="col-lg-9 order-lg-1">
            <div class="text-center">
              <h4>PRIMANIX 100% MONEY BACK GUARANTEE</h4>
              <p>Primanix guarantees results that will blow you away. It's your satisfaction or your money back.</p>
              <p>Stop wasting your time on useless male enhancement products that do you no good. Improve your bedroom game NOW.</p>
              <p class="mb-0"><strong>BE BIG, BE HARD, BE UNFORGETTABLE. Experience <br class="d-none d-lg-block">Primanix by ordering your first bottle today</strong></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="cta-row">
      <div class="top">
        <h3>If you want to learn how Primanix works</h3>
        <h2>visit the How It Works page here</h2>
        <a href="/howitworks" class="button"><span>Click Here</span></a>
      </div>
      <div class="bottom">
        <div class="row align-items-center">
          <div class="col-lg-5  col-xl-6 mb-3 mb-lg-0">
            <img src="/images/home/s5-image0v1.jpg" alt="" class="img-fluid">
          </div>
          <div class="col-lg-7 col-xl-6 ">
            <ul>
              <li>Learn the Science of Primanix</li>
              <li>Review all of the Ingredients within this Award Winning Product</li>
              <li>Read clinical studies that will show you how effective these ingredients are. </li>
            </ul>
            <div class="text-center">
              <a href="/howitworks" class="button"><span>click here to see how it works</span></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Section 6 -->
<section class="section-6">
  <div class="container">
    <h2>To order Scroll Down For order Options</h2>
    <div class="panel mb-4">
      <div class="head">
        <h3>Order Primanix Now With Free Rush Delivery!</h3>
        <img src="/images/money-back2.png" alt="" class="img-fluid d-none d-lg-inline money-back">
      </div>
      <div class="body">
        <div class="secure text-center mb-3 text-lg-end pe-4">
          <img src="/images/secure.jpg" alt="" class="img-fluid">
        </div>
        <div class="row align-items-center">
          <div class="col-lg-5 col-xl-6 mb-3 mb-lg-0">
            <div class="image">
              <img src="/images/bottles3.png" alt="" class="img-fluid">
              <img src="/images/money-back2.png" alt="" class="img-fluid d-lg-none money-back">
            </div>            
          </div>
          <div class="col-lg-7 col-xl-6 ps-xl-0">
            <div class="text">
              <ul>
                <li>Guaranteed to boost erections for increased hardness and frequency</li>
                <li>Guaranteed to maximize your sexual stamina</li>
                <li>Guaranteed to enhance penis size by 35% to 42%</li>
                <li>FREE SHIPPING and hassle-free returns!</li>
              </ul>
              <div class="text-center">
                <a href="/order" class="button mb-4">Order Primanix Now</a>
                <h5>while supplies last</h5>
                <img src="/images/secure2.jpg" alt="" class="img-fluid">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <p class="note my-4 text-center">*Individual Results May Vary</p>
    <div class="bottom-row">
      <div class="chart-head text-center">
        <p class="h3-sub"><strong>Primanix</strong> is so good that users of Blackcore Edge, VirilX, and Duro Max users are switching <strong>EVERY DAY!</strong></p>
        <h3>Look at this chart to see why</h3>
      </div>
      <div class="chart mb-5">
        <table class="table">
          <thead>
            <tr>
              <th><img src="/images/home/rated-no1.jpg" alt="" class="img-fluid mx-auto d-block"></th>
              <th><img src="/images/home/brand-a.jpg" alt="" class="img-fluid mx-auto d-block"></th>
              <th><img src="/images/home/brand-b.jpg" alt="" class="img-fluid mx-auto d-block"></th>
              <th><img src="/images/home/brand-c.jpg" alt="" class="img-fluid mx-auto d-block"></th>
              <th><img src="/images/home/brand-d.jpg" alt="" class="img-fluid mx-auto d-block"></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Advance Syner-Boost Expansion Formula</td>
              <td>YES</td>
              <td>NO</td>
              <td>NO</td>
              <td>NO</td>
            </tr>
            <tr>
              <td>Accelerated-Expansion Formula</td>
              <td>YES</td>
              <td>NO</td>
              <td>NO</td>
              <td>NO</td>
            </tr>
            <tr>
              <td>TongKat Ali Count</td>
              <td>450mg</td>
              <td>0mg</td>
              <td>0mg</td>
              <td>90mg</td>
            </tr>
            <tr>
              <td>TribUlus Terrestris Count</td>
              <td>350mg</td>
              <td>100mg</td>
              <td>50mg</td>
              <td>20mg</td>
            </tr>
            <tr>
              <td>Butea Superba Count</td>
              <td>300mg</td>
              <td>0mg</td>
              <td>0mg</td>
              <td>0mg</td>
            </tr>
            <tr>
              <td>Maca Root</td>
              <td>300mg</td>
              <td>0mg</td>
              <td>0mg</td>
              <td>0mg</td>
            </tr>
            <tr>
              <td>L-Arginine</td>
              <td>300mg</td>
              <td>0mg</td>
              <td>0mg</td>
              <td>0mg</td>
            </tr>
            <tr>
              <td>Clinically Tested</td>
              <td>YES</td>
              <td>NO</td>
              <td>NO</td>
              <td>NO</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="other-text text-center">
        <h4>Get a MASSIVE cock and give her earth-shattering orgasms<span>and add some size TODAY...</span></h4>
        <p class="h4-sub my-3">(We guarantee Primanix will work for you or your MONEY BACK! We promise it will work, as we have <br class="d-none d-xl-block">thousands of satisfied customers)</p>
        <p class="note text-center">*Individual Results May Vary</p>
      </div>
    </div>
  </div>
</section>
<?php
// Render Order Form Template
echo $this->render('/order/order', []);
?>
<?php
$this->params['data']['script'] = <<<EOT
<script src="/js/order.js"></script>
<script>
$(document).ready(function(){
  $(".testimonials").owlCarousel({
    loop: true,
    autoplay: true,
    items: 1,
    nav: false,
    dots: true,
    responsive:{
      992:{
        dots: true,
        nav: true,
      },
    }
  });
});
</script>
EOT;
?>